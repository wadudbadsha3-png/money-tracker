import { NextRequest, NextResponse } from 'next/server'
import { getAllBudgets, addBudget } from '@/lib/mock-data'
import { CreateBudgetInput, ApiResponse } from '@/lib/types'

export async function GET(request: NextRequest) {
  try {
    const budgets = getAllBudgets()
    return NextResponse.json<ApiResponse<typeof budgets>>({
      success: true,
      data: budgets,
    })
  } catch (error) {
    return NextResponse.json<ApiResponse<null>>(
      {
        success: false,
        error: 'Failed to fetch budgets',
      },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body: CreateBudgetInput = await request.json()

    if (!body.categoryId || !body.limit || !body.period) {
      return NextResponse.json<ApiResponse<null>>(
        {
          success: false,
          error: 'Missing required fields',
        },
        { status: 400 }
      )
    }

    if (body.period !== 'monthly' && body.period !== 'yearly') {
      return NextResponse.json<ApiResponse<null>>(
        {
          success: false,
          error: 'Invalid budget period',
        },
        { status: 400 }
      )
    }

    const budget = addBudget({
      categoryId: body.categoryId,
      categoryName: '', // Will be populated from category lookup
      limit: body.limit,
      period: body.period,
    })

    return NextResponse.json<ApiResponse<typeof budget>>(
      {
        success: true,
        data: budget,
      },
      { status: 201 }
    )
  } catch (error) {
    return NextResponse.json<ApiResponse<null>>(
      {
        success: false,
        error: 'Failed to create budget',
      },
      { status: 500 }
    )
  }
}
