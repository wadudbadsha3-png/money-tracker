import { NextRequest, NextResponse } from 'next/server'
import { getAllTransactions, addTransaction } from '@/lib/mock-data'
import { CreateTransactionInput, ApiResponse } from '@/lib/types'

export async function GET(request: NextRequest) {
  try {
    const transactions = getAllTransactions()
    const searchParams = request.nextUrl.searchParams
    const category = searchParams.get('category')
    const type = searchParams.get('type')

    let filtered = transactions

    if (category) {
      filtered = filtered.filter(t => t.category === category)
    }

    if (type && (type === 'income' || type === 'expense')) {
      filtered = filtered.filter(t => t.type === type)
    }

    // Sort by date descending
    filtered.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

    return NextResponse.json<ApiResponse<typeof filtered>>({
      success: true,
      data: filtered,
    })
  } catch (error) {
    return NextResponse.json<ApiResponse<null>>(
      {
        success: false,
        error: 'Failed to fetch transactions',
      },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body: CreateTransactionInput = await request.json()

    if (!body.amount || !body.type || !body.category || !body.date || !body.description) {
      return NextResponse.json<ApiResponse<null>>(
        {
          success: false,
          error: 'Missing required fields',
        },
        { status: 400 }
      )
    }

    if (body.type !== 'income' && body.type !== 'expense') {
      return NextResponse.json<ApiResponse<null>>(
        {
          success: false,
          error: 'Invalid transaction type',
        },
        { status: 400 }
      )
    }

    const transaction = addTransaction({
      amount: body.amount,
      type: body.type,
      category: body.category,
      date: body.date,
      description: body.description,
    })

    return NextResponse.json<ApiResponse<typeof transaction>>(
      {
        success: true,
        data: transaction,
      },
      { status: 201 }
    )
  } catch (error) {
    return NextResponse.json<ApiResponse<null>>(
      {
        success: false,
        error: 'Failed to create transaction',
      },
      { status: 500 }
    )
  }
}
